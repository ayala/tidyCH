"""tidyCH Dispatcharr plugin."""
